﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using GameApplication;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System;

namespace GameApplication.Tests
{
    [TestClass]
    public class Minimum_connectorsTests
    {
        [TestMethod]
        public void PopulateDistancesTest()
        {
            // Arrange
            var minimumConnectorsForm = new Minimum_connectors();

            // Act
            minimumConnectorsForm.PopulateDistances();

            // Assert
            var dataGridView = minimumConnectorsForm.Controls.Find("dataGridView1", true)[0] as DataGridView;
            Assert.IsNotNull(dataGridView);
            Assert.IsTrue(dataGridView.Rows.Count > 0);
        }

        [TestMethod()]
        public void SelectStartCityTest()
        {
            // Arrange
            var minimumConnectorsForm = new Minimum_connectors();
            var privateObject = new PrivateObject(minimumConnectorsForm);

            // Initialize distances field
            var distances = new List<CityDistance>
    {
        new CityDistance { City1 = "City A", City2 = "City B", Distance = 10 },
        new CityDistance { City1 = "City C", City2 = "City D", Distance = 20 },
        // We can add more sample distances as needed
    };
            privateObject.SetField("distances", distances);

            // Act
            privateObject.Invoke("SelectStartCity");

            // Assert
            var startCity = privateObject.GetField("startCity") as string;

            Assert.IsNotNull(startCity, "Start city is null.");
            Assert.IsTrue(distances.Exists(d => d.City1 == startCity || d.City2 == startCity), $"Start city '{startCity}' not found in distances.");
        }

        [TestMethod()]
        public void FindMinimumConnectorsTest()
        {
            // Arrange
            var minimumConnectorsForm = new Minimum_connectors();
            var privateObject = new PrivateObject(minimumConnectorsForm);

            // Initialize distances field
            var distances = new List<CityDistance>
        {
            new CityDistance { City1 = "City A", City2 = "City B", Distance = 10 },
            new CityDistance { City1 = "City B", City2 = "City C", Distance = 15 },
            new CityDistance { City1 = "City A", City2 = "City C", Distance = 20 },
            // Can add more sample distances as needed
        };
            privateObject.SetField("distances", distances);

            // Set the start city
            var startCity = "City A";
            privateObject.SetField("startCity", startCity);

            // Act
            var result = (Dictionary<string, int>)privateObject.Invoke("FindMinimumConnectors", startCity);

            // Assert
            Assert.IsNotNull(result, "Result is null.");
            Assert.IsTrue(result.ContainsKey("City B"), "Result does not contain 'City B'.");
            Assert.IsTrue(result.ContainsKey("City C"), "Result does not contain 'City C'.");
            Assert.AreEqual(10, result["City B"], "Incorrect distance for 'City B'.");
            Assert.AreEqual(15, result["City C"], "Incorrect distance for 'City C'.");


        }

        [TestMethod()]
        public void CalculateTotalDistanceTest()
        {
            // Arrange
            var minimumConnectorsForm = new Minimum_connectors();
            var privateObject = new PrivateObject(minimumConnectorsForm);

            // Create a sample connectors dictionary
            var connectors = new Dictionary<string, int>
        {
            { "City A", 10 },
            { "City B", 15 },
            { "City C", 20 },
            // Can Add more connectors as needed
        };

            // Act
            var result = (int)privateObject.Invoke("CalculateTotalDistance", connectors);

            // Assert
            Assert.AreEqual(45, result, "Incorrect total distance.");
        }

    }   
}
