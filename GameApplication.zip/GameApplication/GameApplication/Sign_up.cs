﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.SqlClient;

namespace GameApplication
{
    public partial class Sign_up : Form
    {
        
        private string connectionString = "Data Source=DESKTOP-KI1B9JP;Initial Catalog=GameApplication2;Integrated Security=True";
        public static string SetValueForText1 = "";

        public Sign_up()
        {
            InitializeComponent();

        }

        private void btnSignUp_Click_1(object sender, EventArgs e)
        {
            SetValueForText1 = txtUsername.Text;

            Minimum_connectors minimum_Connectors = new Minimum_connectors();
            minimum_Connectors.Show();

            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;
            string email = txtEmail.Text;

          
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Example: Checking if the password and confirmation password match
            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Example: Saving the user information to a database
            bool success = SaveUser(username, password, email);

            if (success)
            {
                MessageBox.Show("Sign-up successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clearing the input fields
                txtUsername.Text = string.Empty;
                txtPassword.Text = string.Empty;
                txtConfirmPassword.Text = string.Empty;
                txtEmail.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Failed to save user details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool SaveUser(string username, string password, string email)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the username already exists in the database
                    string checkQuery = "SELECT COUNT(*) FROM Game_user WHERE Username = @Username";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Username", username);
                        int existingUserCount = (int)checkCommand.ExecuteScalar();

                        if (existingUserCount > 0)
                        {
                            MessageBox.Show("Username is already taken. Please choose a different username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }

                    // Encrypt the password using SHA256 hashing algorithm
                    string hashedPassword = GetHashedPassword(password);

                    // Insert the user details into the "Game_user" table
                    string insertQuery = "INSERT INTO Game_user (Username, Password, Email) VALUES (@Username, @Password, @Email)";
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", username);
                        insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                        insertCommand.Parameters.AddWithValue("@Email", email);

                        insertCommand.ExecuteNonQuery();
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during database operations
                MessageBox.Show("An error occurred while saving user details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private string GetHashedPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);

                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < hash.Length; i++)
                {
                    stringBuilder.Append(hash[i].ToString("x2"));
                }

                return stringBuilder.ToString();
            }
        }
         


        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
            txtEmail.Clear();
        }

        private void Sign_up_Load(object sender, EventArgs e)
        {
            // Add a label for navigating to the login page
            Label loginLabel = new Label();
            loginLabel.Text = "Already have an account? Login";
            loginLabel.ForeColor = System.Drawing.Color.Blue;
            loginLabel.Cursor = Cursors.Hand;
            loginLabel.AutoSize = true;
            loginLabel.Location = new System.Drawing.Point(10, 10);
            loginLabel.Click += LoginLabel_Click;

            // Add the label to the main form's controls
            this.Controls.Add(loginLabel);
        }

        private void LoginLabel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login= new Login();
            login.Show();

        }
    }
}