﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GameApplication
{
    public partial class Minimum_connectors : Form
    {
        public List<CityDistance> distances;
        public Dictionary<string, int> connectors;
        public int totalDistance;
        public string startCity;
        public bool isGameStarted;
        public static string user = "";
        public readonly string connectionString = "Data Source=DESKTOP-KI1B9JP;Initial Catalog=GameApplication2;Integrated Security=True";

        public Action<object, object> ShowMessageBox { get; set; }

        public Minimum_connectors()
        {
            InitializeComponent();

            user = Login.SetValueForText1;
        }

        public void Minimum_connectors_Load(object sender, EventArgs e)
        {
            label5.Text = Login.SetValueForText1;

            try
            {
                PopulateDistances();
                GenerateCityConnectionsDiagram();
                btnStartGame.Enabled = true;
                Btn_Submit.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load distances: " + ex.Message);
            }
        }

        public void PopulateDistances()
        {
            distances = new List<CityDistance>();
            Random random = new Random();
            string[] cities = { "City A", "City B", "City C", "City D", "City E", "City F", "City G", "City H", "City I", "City J" };

            try
            {
                // Generating random distances between cities
                for (int i = 0; i < cities.Length; i++)
                {
                    for (int j = i + 1; j < cities.Length; j++)
                    {
                        int distance = random.Next(10, 100); // Generate a random distance between 10 and 100
                        distances.Add(new CityDistance { City1 = cities[i], City2 = cities[j], Distance = distance });
                    }
                }

                dataGridView1.DataSource = distances; // Displaying distances in a DataGridView
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to populate distances: " + ex.Message);
            }
        }

        public void GenerateCityConnectionsDiagram()
        {
            int diagramWidth = 500;
            int diagramHeight = 400;
            int cityRadius = 15;
            int margin = 20;
            int labelOffsetX = 5;
            int labelOffsetY = 5;

            Bitmap diagram = new Bitmap(diagramWidth, diagramHeight);
            using (Graphics g = Graphics.FromImage(diagram))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                int numCities = distances.SelectMany(d => new[] { d.City1, d.City2 }).Distinct().Count();
                float angleStep = 360f / numCities;
                float currentAngle = 0;

                Dictionary<string, Point> cityPositions = new Dictionary<string, Point>();

                // Calculate positions for each city on the diagram
                foreach (var city in distances.SelectMany(d => new[] { d.City1, d.City2 }).Distinct())
                {
                    float radians = currentAngle * (float)Math.PI / 180f;
                    int x = (int)(diagramWidth / 2 + (diagramWidth / 2 - margin) * Math.Cos(radians));
                    int y = (int)(diagramHeight / 2 + (diagramHeight / 2 - margin) * Math.Sin(radians));
                    cityPositions[city] = new Point(x, y);

                    currentAngle += angleStep;
                }

                // Draw connections between cities
                using (Pen pen = new Pen(Color.Green, 2)) // Set the pen color to green
                {
                    foreach (var distance in distances)
                    {
                        Point city1Position = cityPositions[distance.City1];
                        Point city2Position = cityPositions[distance.City2];

                        g.DrawLine(pen, city1Position, city2Position);

                        // Draw distance labels
                        int labelX = (city1Position.X + city2Position.X) / 2 + labelOffsetX;
                        int labelY = (city1Position.Y + city2Position.Y) / 2 + labelOffsetY;
                        g.DrawString(distance.Distance.ToString(), DefaultFont, Brushes.Black, labelX, labelY);

                    }
                }

                // Draw cities
                using (Brush brush = new SolidBrush(Color.Red))
                {
                    foreach (var city in cityPositions)
                    {
                        Point cityPosition = city.Value;
                        g.FillEllipse(brush, cityPosition.X - cityRadius, cityPosition.Y - cityRadius, cityRadius * 2, cityRadius * 2);

                        // Draw city labels
                        int labelX = cityPosition.X - cityRadius + labelOffsetX;
                        int labelY = cityPosition.Y - cityRadius + labelOffsetY;
                        g.DrawString(city.Key, DefaultFont, Brushes.Black, labelX, labelY);
                    }
                }
            }

            pictureBox1.Image = diagram;
        }

        public void btnStartGame_Click(object sender, EventArgs e)
        {
            try
            {
                SelectStartCity();
                MessageBox.Show("The game has started! Your task is to identify the minimum connectors and the total distance to connect all cities starting from " + startCity + ".");
                btnStartGame.Enabled = false;
                Btn_Submit.Enabled = true; // Enable the submit button after starting the game
                isGameStarted = true; // Set the game started flag to true
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to start the game: " + ex.Message);
            }
        }

        public void SelectStartCity()
        {
            startCity = distances[new Random().Next(distances.Count)].City1;
        }

        public Dictionary<string, int> FindMinimumConnectors(string startCity)
        {
            connectors = new Dictionary<string, int>
            {
                [startCity] = 0
            };

            try
            {
                HashSet<string> unvisitedCities = new HashSet<string>(distances.SelectMany(d => new[] { d.City1, d.City2 }).Distinct());
                unvisitedCities.Remove(startCity);

                while (unvisitedCities.Count > 0)
                {
                    CityDistance minDistance = null;

                    foreach (var distance in distances)
                    {
                        if (connectors.ContainsKey(distance.City1) && unvisitedCities.Contains(distance.City2))
                        {
                            if (minDistance == null || distance.Distance < minDistance.Distance)
                            {
                                minDistance = distance;
                            }
                        }
                        else if (connectors.ContainsKey(distance.City2) && unvisitedCities.Contains(distance.City1))
                        {
                            if (minDistance == null || distance.Distance < minDistance.Distance)
                            {
                                minDistance = distance;
                            }
                        }
                    }

                    if (minDistance != null)
                    {
                        if (connectors.ContainsKey(minDistance.City1))
                        {
                            connectors[minDistance.City2] = minDistance.Distance;
                            unvisitedCities.Remove(minDistance.City2);
                        }
                        else
                        {
                            connectors[minDistance.City1] = minDistance.Distance;
                            unvisitedCities.Remove(minDistance.City1);
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to find minimum connectors: " + ex.Message);
            }

            return connectors;
        }

        public int CalculateTotalDistance(Dictionary<string, int> connectors)
        {
            try
            {
                return connectors.Values.Sum();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to calculate total distance: " + ex.Message);
            }
        }

        public void SaveAnswerToDatabase(string playerName, string answer, Dictionary<string, int> connectors)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Save the player's name, answer, and distances between cities in the database
                    string query = "INSERT INTO Minimum_ConnectorsResult (playerName, Answer) VALUES (@playerName, @Answer)";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@playerName", playerName);
                    command.Parameters.AddWithValue("@Answer", answer);

                    command.ExecuteNonQuery();

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to save answer to database: " + ex.Message);
            }
        }

        public void Btn_Submit_Click(object sender, EventArgs e)
        {
            if (!isGameStarted) // Check if the game has started
            {
                MessageBox.Show("Please start the game before submitting your answer.");
                return;
            }

            string playerName = label5.Text.Trim();
            string answer = txtAnswer.Text.Trim();

            if (string.IsNullOrEmpty(playerName) || string.IsNullOrEmpty(answer))
            {
                MessageBox.Show("Please enter a valid player name and answer.");
                return;
            }

            try
            {
                connectors = FindMinimumConnectors(startCity);
                totalDistance = CalculateTotalDistance(connectors);

                if (answer == $"{string.Join(", ", connectors.Select(c => c.Key + "-" + c.Value))} (Total Distance: {totalDistance})")
                {
                    MessageBox.Show("Congratulations! Your answer is correct!");
                    try
                    {
                        SaveAnswerToDatabase(playerName, answer, connectors);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Failed to save answer: " + ex.Message);
                    }
                }
                else
                {
                    DialogResult result = MessageBox.Show("Incorrect answer. The correct answer is:\n" +
                        $"{string.Join(", ", connectors.Select(c => c.Key + "-" + c.Value))} " +
                        $"(Total Distance: {totalDistance})\n\nDo you want to replay?", "Incorrect Answer", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        btnStartGame.Enabled = true;
                        Btn_Submit.Enabled = false; // Disable the submit button after replay
                        isGameStarted = false; // Reset the game started flag
                    }
                    else if (result == DialogResult.No)
                    {
                        Application.Exit();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        public void Btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void btn_clear_Click(object sender, EventArgs e)
        {
            txtAnswer.Clear();
        }
    }

    public class CityDistance
    {
        public string City1 { get; set; }
        public string City2 { get; set; }
        public int Distance { get; set; }
    }
}
